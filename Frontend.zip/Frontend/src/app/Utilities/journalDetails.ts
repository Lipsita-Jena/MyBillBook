export class journalDetails{
    date:string='';
    transaction:String='';
    constructor(date: string,transaction: any){
        this.date=date;
        this.transaction=transaction;
    }

}