import { ExpenseDetails } from "./ExpenseDetails";

export class User{
    name:String='';
    email:String='';
    phone:number=0;
    occupation:String='';
    password:String='';
    expenseList:ExpenseDetails[]=[];
    
    constructor(){}
    

}