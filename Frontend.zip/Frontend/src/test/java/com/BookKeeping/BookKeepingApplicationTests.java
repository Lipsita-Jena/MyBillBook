package com.BookKeeping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookKeepingApplicationTests {

	@Test
	void contextLoads() {
	}

}
