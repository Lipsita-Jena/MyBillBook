package com.BookKeeping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookKeepingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookKeepingApplication.class, args);
		System.out.println("hello");
	}

}
